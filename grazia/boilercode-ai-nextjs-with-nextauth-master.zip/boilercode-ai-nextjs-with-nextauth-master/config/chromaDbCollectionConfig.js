const CHROMA_DB_COLLECTION_NAME = "your_collection_name";

export default CHROMA_DB_COLLECTION_NAME;
